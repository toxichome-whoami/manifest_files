addappid(1465460)
addappid(1465461, 1, "e2a62ed18d9479e7bca56d425a8c527bacdfc7435666810eafeea55fe3e7746f")
setManifestid(1465461, "7823536165754729923")
-- Toxic Home - Game name = (Infection Free Zone)