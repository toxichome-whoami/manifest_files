addappid(2379780)
addappid(2379781, 1, "16261e41d3e864018778d4a1d81658521a67d9ffb8543ea7e3e21f0685721af1")
setManifestid(2379781, "3307846682177631994")
-- Toxic Home - Game name = (Balatro)