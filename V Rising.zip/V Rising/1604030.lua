addappid(1604030)
-- All DLCs
addappid(2833600)
addappid(2358430)
addappid(2169180)
addappid(1997210)
addappid(1983901)
addappid(1983900)
--
addappid(1604031, 1, "e51d4f407e118a5477cab33cf9cd3340057f5aa111772951f47d76b05b594606")
setManifestid(1604031, "6315112099767094635")
-- Toxic Home - Game name = (V Rising)