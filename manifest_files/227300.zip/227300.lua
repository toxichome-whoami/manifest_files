addappid(227300)
addappid(1650650, 1, "18a31f4193d242da5acc55e09f2959070cfe4a0260c63766f4b90962382a4f26")
setManifestid(1650650, "1383614172783786394", 0)
addappid(227300, 1, "4efc6eb3aea74680b954e5b88327ec42ef52984cb390f9dc905aab42a4ae6652")
setManifestid(227300, "7470047004816869937", 0)
addappid(227301, 1, "1baf18f6181ad3f9ce663dab07f93ba0f3f5194c82b64785e4cd9f63f3a56b28")
setManifestid(227301, "6269218232072324523", 0)
addappid(227302, 1, "edfb6f81d8ec91175145051344fdf788840b2235df88cca912a7602de47f54af")
setManifestid(227302, "578211316878011517", 0)
addappid(227310, 1, "b06666dc044784f4331b6572132630cb7b36fd1c83688aa215f808fc8460729d")
setManifestid(227310, "8986069560800906948", 0)
addappid(2371170, 1, "1fcd77106389d142c555008bba4ce9bff600547c679de34c5193180067dbc949")
setManifestid(2371170, "7809383020142126541", 0)
addappid(2611740, 1, "72f023418f51891b17a771cd733b110c092a6a17d8dddbecc476f0fdc506fcfd")
setManifestid(2611740, "5009768597697504470", 0)
addappid(2932420, 1, "1bb65d2da60e4acf76f3539c02dc2a89ca727e99a4276f7c7dc3084abe451f46")
setManifestid(2932420, "8290080232077515320", 0)
addappid(3035040, 1, "265987b6be428d11dfc1ce48fabe6cd08e1382d83f8f4fea2b873f5bf04413cc")
setManifestid(3035040, "6665593843249505581", 0)
addappid(3323350, 1, "f052b8b9da688d69eb6b7d9162ddf68fb0caa23dcb84a22cbf5f4125399db031")
setManifestid(3323350, "8695049842862174770", 0)
addappid(3323360, 1, "3759b4df13b1da02928e0a58473807f4ddc07f9b1f3513dff867458136e36715")
setManifestid(3323360, "6312086033646729789", 0)
addappid(3354860, 1, "7ab4299e2db99a337ec4ecbda76dcd0530766e8c3790e8a0419e98f8847fa833")
setManifestid(3354860, "6789632481762577527", 0)
addappid(388478, 1, "37e441d79e75d5e2fc7af4075ea3afbb4309ce05a27fc63f81419867ee29cc84")
setManifestid(388478, "614205605403850615", 0)

-- All DLCs
addappid(227310) -- Euro Truck Simulator 2 - Going East!
addappid(258460) -- Euro Truck Simulator 2 - Halloween Paint Jobs DLC
addappid(266930) -- Euro Truck Simulator 2 - Ice Cold Paint Jobs DLC
addappid(292320) -- Euro Truck Simulator 2 - Force of Nature Paint Jobs DLC
addappid(297790) -- Euro Truck Simulator 2 - Metallic Paint Jobs DLC
addappid(297791) -- Euro Truck Simulator 2 - UK Paint Jobs DLC
addappid(297792) -- Euro Truck Simulator 2 - Irish Paint Jobs DLC
addappid(297793) -- Euro Truck Simulator 2 - Scottish Paint Jobs DLC
addappid(301180) -- Euro Truck Simulator 2 - Flip Paint Designs DLC
addappid(304020) -- Euro Truck Simulator 2 - Polish Paint Jobs Pack
addappid(304140) -- Euro Truck Simulator 2 - Brazilian Paint Jobs Pack
addappid(304210) -- Euro Truck Simulator 2 - Fantasy Paint Jobs Pack
addappid(304213) -- Euro Truck Simulator 2 - Canadian Paint Jobs Pack
addappid(304211) -- Euro Truck Simulator 2 - USA Paint Jobs Pack
addappid(304214) -- Euro Truck Simulator 2 - High Power Cargo Pack
addappid(318500) -- Euro Truck Simulator 2 - German Paint Jobs Pack
addappid(318510) -- Euro Truck Simulator 2 - French Paint Jobs Pack
addappid(318511) -- Euro Truck Simulator 2 - Czech Paint Jobs Pack
addappid(318520) -- Euro Truck Simulator 2 - Christmas Paint Jobs Pack
addappid(318521) -- Euro Truck Simulator 2 - Raven Truck Design Pack
addappid(304212) -- Euro Truck Simulator 2 - Scandinavia
addappid(347210) -- Euro Truck Simulator 2 - Danish Paint Jobs Pack
addappid(347190) -- Euro Truck Simulator 2 - Norwegian Paint Jobs Pack
addappid(347211) -- Euro Truck Simulator 2 - Swedish Paint Jobs Pack
addappid(347212) -- Euro Truck Simulator 2 - Viking Legends
addappid(347213) -- Euro Truck Simulator 2 - Russian Paint Jobs Pack
addappid(266931) -- Euro Truck Simulator 2 - Prehistoric Paint Jobs Pack
addappid(388470) -- Euro Truck Simulator 2 - Cabin Accessories
addappid(388471) -- Euro Truck Simulator 2 - Michelin Fan Pack
addappid(388472) -- Euro Truck Simulator 2 - Japanese Paint Jobs Pack
addappid(388473) -- Euro Truck Simulator 2 - PC Gamer DLC
addappid(388474) -- Euro Truck Simulator 2 - Turkish Paint Jobs Pack
addappid(388475) -- Euro Truck Simulator 2 - Wheel Tuning Pack
addappid(388476) -- Euro Truck Simulator 2 - Italian Paint Jobs Pack
addappid(388477) -- Euro Truck Simulator 2 - Schwarzmüller Trailer Pack
addappid(388478) -- Euro Truck Simulator 2 - Rocket League Promo
addappid(388479) -- Euro Truck Simulator 2 - Hungarian Paint Jobs Pack
addappid(461240) -- Euro Truck Simulator 2 - Slovak Paint Jobs Pack
addappid(461241) -- Euro Truck Simulator 2 - Spanish Paint Jobs Pack
addappid(461243) -- Euro Truck Simulator 2 - Austrian Paint Jobs Pack
addappid(461242) -- Euro Truck Simulator 2 - National Window Flags
addappid(461244) -- Euro Truck Simulator 2 - Mighty Griffin Tuning Pack
addappid(461245) -- Euro Truck Simulator 2 - South Korean Paint Jobs Pack
addappid(461246) -- Euro Truck Simulator 2 - Swiss Paint Jobs Pack
addappid(461247) -- Euro Truck Simulator 2 - Chinese Paint Jobs Pack
addappid(461248) -- Euro Truck Simulator 2 - Pirate Paint Jobs Pack
addappid(461249) -- Euro Truck Simulator 2 - XF Tuning Pack
addappid(526950) -- Euro Truck Simulator 2 - Lunar New Year Pack
addappid(531131) -- Euro Truck Simulator 2 - Heavy Cargo Pack
addappid(531130) -- Euro Truck Simulator 2 - Vive la France !
addappid(540721) -- Euro Truck Simulator 2 - Belgian Paint Job Pack
addappid(540720) -- Euro Truck Simulator 2 - Finnish Paint Jobs Pack
addappid(558240) -- Euro Truck Simulator 2 - Dragon Truck Design Pack
addappid(558242) -- Euro Truck Simulator 2 - Australian Paint Jobs Pack
addappid(558243) -- Euro Truck Simulator 2 - Valentine's Paint Jobs Pack
addappid(558244) -- Euro Truck Simulator 2 - Italia
addappid(558245) -- Euro Truck Simulator 2 - Special Transport
addappid(876980) -- Euro Truck Simulator 2 - Portuguese Paint Jobs Pack
addappid(909640) -- Euro Truck Simulator 2 - Dutch Paint Jobs Pack
addappid(925650) -- Euro Truck Simulator 2 - Space Paint Jobs Pack
addappid(933610) -- Euro Truck Simulator 2 - Krone Trailer Pack
addappid(925580) -- Euro Truck Simulator 2 - Beyond the Baltic Sea
addappid(980592) -- Euro Truck Simulator 2 - Lithuanian Paint Jobs Pack
addappid(980590) -- Euro Truck Simulator 2 - Estonian Paint Jobs Pack
addappid(980591) -- Euro Truck Simulator 2 - Latvian Paint Jobs Pack
addappid(1117140) -- Euro Truck Simulator 2 - Goodyear Tyres Pack
addappid(1056761) -- Euro Truck Simulator 2 - Actros Tuning Pack
addappid(1056760) -- Euro Truck Simulator 2 -  Road to the Black Sea
addappid(1068290) -- Euro Truck Simulator 2 - Pink Ribbon Pack
addappid(1159030) -- Euro Truck Simulator 2 - Bulgarian Paint Jobs Pack
addappid(1209461) -- Euro Truck Simulator 2 - HS-Schoch Tuning Pack
addappid(1299530) -- Euro Truck Simulator 2 - FH Tuning Pack
addappid(1415700) -- Euro Truck Simulator 2 - Super Stripes Paint Jobs Pack
addappid(1456860) -- Euro Truck Simulator 2 - al
addappid(1209460) -- Euro Truck Simulator 2 - Iberia
addappid(1650650) -- Euro Truck Simulator 2 - DAF XG/XG+
addappid(1704460) -- Euro Truck Simulator 2 - Volvo Construction Equipment
addappid(1536500) -- Euro Truck Simulator 2 - Heart of Russia
addappid(1918370) -- Euro Truck Simulator 2 - Ukrainian Paint Jobs Pack
addappid(1967640) -- Euro Truck Simulator 2 - Renault Trucks T Tuning Pack
addappid(2004210) -- Euro Truck Simulator 2 - WB
addappid(1967650) -- Euro Truck Simulator 2 - Street Art Paint Jobs Pack
addappid(2193220) -- Euro Truck Simulator 2 - Feldbinder Trailer Pack

-- Generated By "Manilua Creator" (Toxic Home) - Game name = (Euro Truck Simulator 2 - 227300)
-- Join our discord server (Toxic Home): https://discord.gg/3ShGjfj6je
