-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1546990)
addappid(1546991,1,"8ffae608bee3a6766651bc7b0b2122f7248955251de38eafb6161ea30434979d")
setManifestid(1546991,"4220390542788625308", 0)