addappid(414341)
addappid(414341, 1, "b52b49b1aa5b2931a20af4d509e604d4e96a00895d7e75bf04acaffa573ebe09")
setManifestid(414341, "3390494925423867663")
-- Toxic Home - Game name = (Hellblade: Senua's Sacrifice)