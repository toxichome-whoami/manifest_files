addappid(555220)
addappid(568294, 1, "52154dc64f1c821863f228f624c37174d1777bb1391cd533e228624d0f4156a3")
setManifestid(568294, "4523152730492234181")
-- Toxic Home - Game name = (Detention)