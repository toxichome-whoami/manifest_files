addappid(501940)
addappid(501941, 1, "37d28ae3c52ef678781182a8ed98362df16d166ff612e471aface13fab85884a")
setManifestid(501941, "6923227730959814057")
-- Toxic Home - Game name = (Hikikomori No Chuunibyou)